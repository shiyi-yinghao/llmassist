import logging
import os
from functools import wraps

class DatasetManager:  
    def init(data):
        print(data)

