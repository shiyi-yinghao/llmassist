# LLM_Assist

LLM_Assist is a easy assist package for Large Language model inference and fine-tuning.

## Installation

You can install LLM_Assist using pip:

```bash
pip install llmassist

